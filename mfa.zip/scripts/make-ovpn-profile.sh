#!/bin/bash

### Request certificate for a user
docker exec -it openvpn bash -c "easyrsa build-client-full $1 nopass"

### Check a free address 
# (DHCP)

### Create a ccd file
sudo tee /opt/openvpn-ccd/$1 <<EOF
push \"route 34.210.253.67 255.255.255.255\"      # adm.bloomex.ca
push \"route 54.214.4.160 255.255.255.255\"       # sip2.bloomex.ca
push \"route 34.218.213.218 255.255.255.255\"     # rchat.bloomex.ca
push \"route 54.190.47.145 255.255.255.255\"      # ec2-54-190-47-145.us-west-2.compute.amazonaws.com
push \"route 54.187.97.234 255.255.255.255\"      # cloud.necs.ca
push \"route 35.81.75.37 255.255.255.255\"        # cloud.necs.ca
push \"route 52.10.229.143 255.255.255.255\"      # ec2-52-10-229-143.us-west-2.compute.amazonaws.com
push \"route 52.36.199.0 255.255.255.255\"        # dev3.necs.ca
push \"route 18.156.127.231 255.255.255.255\"     # adm-eu.necs.ca
push \"route 52.37.138.109 255.255.255.255\"      # devd01.necs.ca
push \"route 54.200.0.77 255.255.255.255\"        # orca.necs.ca
push \"route 35.165.118.145 255.255.255.255\"     # chat.bloomex.ca
push \"route 54.200.133.80 255.255.255.255\"      # adm.blossomshop.ca
push \"route 35.81.75.37 255.255.255.255\"        # wiki.necs.ca
EOF

### Create a user in container
docker exec -it openvpn bash -c "adduser -D $1"

### Create a google-auth private key
docker exec -it openvpn bash -c "su - $1 -c 'google-authenticator --time-based --no-confirm --window=5 --rate-limit=10 --rate-time=60 --disallow-reuse --force --secret=/etc/google-auth/$1'"

### Create .ovpn file
tee /opt/openvpn-profiles/$1.ovpn <<EOF
client
user $1
remote 34.209.171.30 1199
dev tun
proto udp
data-ciphers AES-256-GCM:AES-128-GCM
auth SHA512
nobind
resolv-retry infinite
remote-cert-tls server
persist-key
persist-tun
verb 3
key-direction 1
#tun-mtu 1500
#mssfix 1420
#fragment 1472
#txqueuelen 1500
#hand-window 300
verb 3
auth-nocache
auth-user-pass
<ca>
`cat /root/pki/ca.crt `
</ca>
<cert>
`grep -Pzo '(?s)-----BEGIN CERTIFICATE-----(.*)-----END CERTIFICATE-----' /root/pki/issued/$1.crt`
</cert>
<key>
`cat /root/pki/private/$1.key`
</key>
EOF
